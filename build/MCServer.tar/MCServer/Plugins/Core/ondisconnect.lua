function OnDisconnect(Player)
	AddMessage(nil, " " .. Player:GetName() .. " has left the game.")
end